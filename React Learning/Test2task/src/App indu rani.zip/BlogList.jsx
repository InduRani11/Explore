import React, { useState, useEffect } from 'react'
import BlogCard from './BlogCard'

export default function BlogList({data, Category}) {

      let [FilterData,setFilterData]=useState([]);
      useEffect( ()=>{setFilterData(data.filter((val) => val.category === Category))},[data]);
  return (
    <div className='p-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8'>
      <BlogCard data={FilterData}/>
    </div>
  )
}
